package com.example.voiceassistant

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.SearchManager
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telephony.SmsManager
import android.view.KeyEvent
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Gemini जो "ACTION" भेजता है, उन्हें फ़ोन पर चलाता है */
class ActionRunner(private val ctx: Context) {

    private var torchOn = false
    private val needA11y = "पहले ऐप में एक्सेसिबिलिटी चालू करें"
    private val acc: PhoneControlService? get() = PhoneControlService.instance

    fun needsConfirm(a: JSONObject) = a.optString("type") in setOf("call", "sms", "whatsapp")

    fun describe(a: JSONObject): String {
        val to = a.optString("to").ifEmpty { a.optString("name") }
        return when (a.optString("type")) {
            "call" -> "$to को कॉल करूँ? हाँ या नहीं बोलिए"
            "sms" -> "$to को SMS भेजूँ: ${a.optString("text")}। हाँ या नहीं?"
            "whatsapp" -> "$to को व्हाट्सऐप पर भेजूँ: ${a.optString("text")}। हाँ या नहीं?"
            else -> "करूँ? हाँ या नहीं?"
        }
    }

    /** काम करो। बोलने लायक नतीजा (या गलती का संदेश) लौटाता है, वरना null */
    fun run(a: JSONObject): String? =
        try { exec(a) } catch (e: Exception) { "यह काम नहीं हो पाया" }

    private fun has(p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun launch(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        (acc ?: ctx).startActivity(i)
    }

    @Suppress("DEPRECATION")
    private fun smsManager(): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java)
        else SmsManager.getDefault()

    private fun exec(a: JSONObject): String? {
        when (a.optString("type")) {
            "alarm" -> launch(Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour") % 24)
                putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute"))
                putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label"))
                putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            })
            "timer" -> launch(Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, a.optInt("seconds", 60))
                putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            })
            "call" -> {
                val num = resolveNumber(a) ?: return "इस नाम का नंबर नहीं मिला"
                val i = if (has(Manifest.permission.CALL_PHONE))
                    Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(num)))
                else Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num)))
                launch(i)
            }
            "sms" -> {
                val num = resolveNumber(a) ?: return "इस नाम का नंबर नहीं मिला"
                if (!has(Manifest.permission.SEND_SMS)) return "SMS की परमिशन नहीं है"
                val sm = smsManager()
                sm.sendMultipartTextMessage(num, null, sm.divideMessage(a.optString("text")), null, null)
                return "SMS भेज दिया"
            }
            "whatsapp" -> {
                var num = (resolveNumber(a) ?: return "इस नाम का नंबर नहीं मिला").filter { it.isDigit() }
                if (num.length == 10) num = "91$num"
                else if (num.length == 11 && num.startsWith("0")) num = "91" + num.drop(1)
                val uri = Uri.parse("https://wa.me/$num?text=" + Uri.encode(a.optString("text")))
                var started = false
                for (p in listOf("com.whatsapp", "com.whatsapp.w4b")) {
                    try { launch(Intent(Intent.ACTION_VIEW, uri).setPackage(p)); started = true; break }
                    catch (e: Exception) { }
                }
                if (!started) return "व्हाट्सऐप इंस्टॉल नहीं मिला"
                val svc = acc ?: return "मैसेज तैयार है, पर भेजने के लिए एक्सेसिबिलिटी चालू करें"
                for (t in 1..9) {                    // चैट खुलने में समय लगता है
                    Thread.sleep(900)
                    if (svc.clickSend()) return "व्हाट्सऐप पर भेज दिया"
                }
                return "मैसेज तैयार है, पर भेजें बटन नहीं मिला"
            }
            "contact" -> {
                val num = resolveNumber(a) ?: return "इस नाम का नंबर नहीं मिला"
                val who = a.optString("to").ifEmpty { a.optString("name") }
                return "$who का नंबर $num है"
            }
            "play_music" -> {
                val q = a.optString("query")
                try {
                    launch(Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
                        putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                        putExtra(SearchManager.QUERY, q)
                    })
                } catch (e: Exception) {
                    launch(Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))
                }
            }
            "media" -> {
                val code = when (a.optString("cmd")) {
                    "pause" -> KeyEvent.KEYCODE_MEDIA_PAUSE
                    "play" -> KeyEvent.KEYCODE_MEDIA_PLAY
                    "next" -> KeyEvent.KEYCODE_MEDIA_NEXT
                    "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                    "stop" -> KeyEvent.KEYCODE_MEDIA_STOP
                    else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
                }
                val am = ctx.getSystemService(AudioManager::class.java)
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
            }
            "open_app" -> return openApp(a)
            "flashlight" -> {
                val cm = ctx.getSystemService(CameraManager::class.java)
                val id = cm.cameraIdList.firstOrNull {
                    cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                } ?: return "इस फ़ोन में टॉर्च नहीं मिली"
                torchOn = if (a.has("on")) a.optBoolean("on") else !torchOn
                cm.setTorchMode(id, torchOn)
            }
            "volume" -> {
                val am = ctx.getSystemService(AudioManager::class.java)
                val s = AudioManager.STREAM_MUSIC
                val max = am.getStreamMaxVolume(s)
                val ui = AudioManager.FLAG_SHOW_UI
                when {
                    a.has("level") -> am.setStreamVolume(s, (max * a.optInt("level") / 100).coerceIn(0, max), ui)
                    a.optString("dir") == "up" -> am.adjustStreamVolume(s, AudioManager.ADJUST_RAISE, ui)
                    a.optString("dir") == "down" -> am.adjustStreamVolume(s, AudioManager.ADJUST_LOWER, ui)
                    a.optString("dir") == "mute" -> am.setStreamVolume(s, 0, ui)
                    a.optString("dir") == "max" -> am.setStreamVolume(s, max, ui)
                }
            }
            "maps" -> {
                val q = Uri.encode(a.optString("query"))
                try {
                    launch(Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=$q"))
                        .setPackage("com.google.android.apps.maps"))
                } catch (e: Exception) {
                    launch(Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$q")))
                }
            }
            "settings" -> {
                val act = when (a.optString("page")) {
                    "wifi" -> Settings.ACTION_WIFI_SETTINGS
                    "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                    "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS
                    "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS
                    "display" -> Settings.ACTION_DISPLAY_SETTINGS
                    "sound" -> Settings.ACTION_SOUND_SETTINGS
                    "battery" -> Settings.ACTION_BATTERY_SAVER_SETTINGS
                    else -> Settings.ACTION_SETTINGS
                }
                launch(Intent(act))
            }
            "calendar" -> return readCalendar(a.optInt("days", 1))
            "notifications" -> return acc?.recentNotifications() ?: needA11y
            "navigate" -> {
                val svc = acc ?: return needA11y
                val g = when (a.optString("where")) {
                    "back" -> AccessibilityService.GLOBAL_ACTION_BACK
                    "home" -> AccessibilityService.GLOBAL_ACTION_HOME
                    "recents" -> AccessibilityService.GLOBAL_ACTION_RECENTS
                    "notifications" -> AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS
                    "quick_settings" -> AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS
                    "lock" -> AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN
                    "screenshot" -> AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT
                    "power" -> AccessibilityService.GLOBAL_ACTION_POWER_DIALOG
                    else -> return null
                }
                svc.performGlobalAction(g)
            }
            "click" -> {
                val svc = acc ?: return needA11y
                if (!svc.clickText(a.optString("text"))) return "स्क्रीन पर '${a.optString("text")}' नहीं मिला"
            }
            "scroll" -> (acc ?: return needA11y).swipe(a.optString("dir") != "up")
            "type" -> {
                val svc = acc ?: return needA11y
                if (!svc.typeText(a.optString("text"))) return "लिखने की जगह नहीं मिली"
            }
        }
        return null
    }

    private fun openApp(a: JSONObject): String? {
        val names = listOf(a.optString("name"), a.optString("name_en"))
            .filter { it.isNotBlank() }.map { it.lowercase() }
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val pkg = apps.firstOrNull { r ->
            val l = r.loadLabel(pm).toString().lowercase()
            names.any { l.contains(it) || it.contains(l) }
        }?.activityInfo?.packageName
        val i = pkg?.let { pm.getLaunchIntentForPackage(it) }
            ?: return "${names.firstOrNull() ?: "वह"} ऐप नहीं मिला"
        launch(i)
        return null
    }

    /** नाम या नंबर से फ़ोन नंबर ढूँढता है (कॉन्टैक्ट में हिंदी/अंग्रेज़ी दोनों नाम आज़माता है) */
    private fun resolveNumber(a: JSONObject): String? {
        val spoken = a.optString("to").ifEmpty { a.optString("name") }
        val digits = spoken.filter { it.isDigit() || it == '+' }
        if (digits.count { it.isDigit() } >= 7) return digits
        if (!has(Manifest.permission.READ_CONTACTS)) return null
        for (name in listOf(spoken, a.optString("to_en")).filter { it.isNotBlank() }) {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
                arrayOf("%$name%"), null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0)
            }
        }
        return null
    }

    private fun readCalendar(days: Int): String {
        if (!has(Manifest.permission.READ_CALENDAR)) return "कैलेंडर की परमिशन नहीं है"
        val start = System.currentTimeMillis()
        val end = start + days.coerceIn(1, 30) * 86_400_000L
        val b = CalendarContract.Instances.CONTENT_URI.buildUpon()
        ContentUris.appendId(b, start)
        ContentUris.appendId(b, end)
        val out = ArrayList<String>()
        ctx.contentResolver.query(
            b.build(),
            arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN,
                CalendarContract.Instances.ALL_DAY),
            null, null, "${CalendarContract.Instances.BEGIN} ASC")?.use { c ->
            val fmt = SimpleDateFormat("d MMM, h:mm a", Locale.getDefault())
            while (c.moveToNext() && out.size < 8) {
                val title = c.getString(0) ?: "बिना नाम"
                out += if (c.getInt(2) == 1) "$title (पूरे दिन)"
                else "$title, ${fmt.format(Date(c.getLong(1)))}"
            }
        }
        return if (out.isEmpty()) "इस दौरान कोई कार्यक्रम नहीं है"
        else "आपके कार्यक्रम: " + out.joinToString("; ")
    }
}
