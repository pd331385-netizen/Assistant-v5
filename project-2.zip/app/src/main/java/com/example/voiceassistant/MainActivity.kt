package com.example.voiceassistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

/** ऐप का लोगो: ग्रेडिएंट गोला, माइक और साउंड वेव्स (कोड से बना, कोई इमेज फ़ाइल नहीं चाहिए) */
class LogoView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2; val cy = h / 2; val r = minOf(w, h) / 2
        p.style = Paint.Style.FILL
        p.shader = LinearGradient(0f, 0f, w, h, 0xFF7C4DFF.toInt(), 0xFF00E5FF.toInt(), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r * 0.95f, p)
        p.shader = null
        p.color = Color.WHITE
        val mw = r * 0.26f
        c.drawRoundRect(cx - mw, cy - r * 0.55f, cx + mw, cy + r * 0.08f, mw, mw, p)
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = r * 0.09f
        c.drawArc(cx - r * 0.42f, cy - r * 0.38f, cx + r * 0.42f, cy + r * 0.42f, 20f, 140f, false, p)
        c.drawLine(cx, cy + r * 0.42f, cx, cy + r * 0.62f, p)
        c.drawLine(cx - r * 0.2f, cy + r * 0.62f, cx + r * 0.2f, cy + r * 0.62f, p)
        p.alpha = 150
        val wave = RectF(cx - r * 0.78f, cy - r * 0.55f, cx + r * 0.78f, cy + r * 0.3f)
        c.drawArc(wave, -40f, 80f, false, p)
        c.drawArc(wave, 140f, 80f, false, p)
        p.alpha = 255
    }
}

class MainActivity : Activity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val sp by lazy { getSharedPreferences("settings", MODE_PRIVATE) }

    private lateinit var homeScroll: ScrollView
    private lateinit var settingsScroll: ScrollView
    private lateinit var mainBtn: Button
    private lateinit var status: TextView
    private lateinit var a11y: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun shape(color: Int, radius: Int = 28, stroke: Int? = null) = GradientDrawable().apply {
        cornerRadius = dp(radius).toFloat(); setColor(color)
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun label(s: String, size: Float, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = s; textSize = size; setTextColor(color); gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, Typeface.BOLD)
        }

    private fun button(s: String, fill: Int, stroke: Int? = null, onClick: () -> Unit) =
        Button(this).apply {
            text = s; setTextColor(Color.WHITE); isAllCaps = false; textSize = 16f
            background = shape(fill, 28, stroke)
            setOnClickListener { onClick() }
        }

    private fun field(hint: String, value: String, secret: Boolean) = EditText(this).apply {
        this.hint = hint; setText(value); setHintTextColor(0x88FFFFFF.toInt()); setTextColor(Color.WHITE)
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = shape(0x22FFFFFF, 16, 0x33FFFFFF)
        isSingleLine = true
        inputType = InputType.TYPE_CLASS_TEXT or
            (if (secret) InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_TEXT_VARIATION_URI)
    }

    private fun lp(top: Int = 0, w: Int = MATCH, h: Int = WRAP) =
        LinearLayout.LayoutParams(w, h).apply { topMargin = dp(top) }

    private fun column() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(dp(24), dp(48), dp(24), dp(24))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(0xFF0F0C29.toInt(), 0xFF302B63.toInt(), 0xFF24243E.toInt()))
        }
        homeScroll = ScrollView(this).apply { addView(buildHome()) }
        settingsScroll = ScrollView(this).apply { addView(buildSettings()); visibility = View.GONE }
        root.addView(homeScroll); root.addView(settingsScroll)
        setContentView(root)
        refresh()
    }

    // ---------- होम स्क्रीन ----------
    private fun buildHome(): View = column().apply {
        addView(LogoView(context), lp(0, dp(120), dp(120)))
        addView(label("धाकड़ असिस्टेंट", 28f, bold = true), lp(16))
        addView(label("बस बोलिए, मैं सुन रहा हूँ", 15f, 0xFFB8B8D8.toInt()), lp(4))

        status = label("", 14f, 0xFF00E5FF.toInt())
        addView(status, lp(28))
        a11y = label("", 13f, 0xFFB8B8D8.toInt())
        addView(a11y, lp(6))

        mainBtn = button("", 0xFF7C4DFF.toInt()) { toggle() }
        addView(mainBtn, lp(12, MATCH, dp(64)))

        addView(LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(16), dp(20), dp(16))
            background = shape(0x22FFFFFF, 20, 0x22FFFFFF)
            addView(label("मैं क्या कर सकता हूँ", 14f, Color.WHITE, true))
            addView(label("⏰ अलार्म, टाइमर   📞 कॉल, SMS, व्हाट्सऐप\n🌦 मौसम और लाइव खबरें   🎵 गाने\n📇 कॉन्टैक्ट, कैलेंडर, नोटिफ़िकेशन\n🔦 टॉर्च, वॉल्यूम, ऐप खोलना\n♿ फ़ोन कंट्रोल (एक्सेसिबिलिटी)   🧠 याददाश्त", 14f,
                0xFFD0D0E8.toInt()), lp(10))
        }, lp(28))

        addView(button("⚙  सेटिंग (API)", 0x22FFFFFF, 0x55FFFFFF) { showSettings(true) },
            lp(20, MATCH, dp(52)))
        addView(button("🎮  ऐप खोलने की परमिशन (Overlay)", 0x11FFFFFF, 0x33FFFFFF) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }, lp(10, MATCH, dp(52)))

        addView(button("♿  एक्सेसिबिलिटी चालू करें (फ़ोन कंट्रोल)", 0x22FFFFFF, 0x55FFFFFF) {
            Toast.makeText(context, "सूची में \"धाकड़ असिस्टेंट\" चुनकर चालू करें", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, lp(10, MATCH, dp(52)))
        addView(button("🔐  सारी परमिशन दें (कॉन्टैक्ट, SMS, कॉल, कैलेंडर)", 0x22FFFFFF, 0x55FFFFFF) {
            askAll()
        }, lp(10, MATCH, dp(52)))
        addView(button("🔋  बैकग्राउंड में चलने दें (Battery)", 0x11FFFFFF, 0x33FFFFFF) {
            val pm = getSystemService(PowerManager::class.java)
            if (pm.isIgnoringBatteryOptimizations(packageName))
                Toast.makeText(context, "पहले से चालू है ✅", Toast.LENGTH_SHORT).show()
            else startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:$packageName")))
        }, lp(10, MATCH, dp(52)))

        addView(label("बनाने वाले: धाकड़ 💪", 13f, 0xFF9A9AC0.toInt(), true), lp(36))
    }

    // ---------- सेटिंग स्क्रीन ----------
    private fun buildSettings(): View = column().apply {
        addView(label("⚙  सेटिंग", 24f, bold = true))
        addView(label("Gemini API", 13f, 0xFFB8B8D8.toInt()), lp(4))

        addView(label("API Key", 13f, 0xFFB8B8D8.toInt()).apply { gravity = Gravity.START }, lp(28))
        val keyEt = field("यहाँ अपनी API key पेस्ट करें", sp.getString("api_key", "") ?: "", true)
        addView(keyEt, lp(6))

        addView(label("मॉडल", 13f, 0xFFB8B8D8.toInt()).apply { gravity = Gravity.START }, lp(18))
        val modelEt = field("gemini-3.5-flash-lite",
            sp.getString("model", AssistantService.DEFAULT_MODEL) ?: AssistantService.DEFAULT_MODEL, false)
        addView(modelEt, lp(6))

        addView(label("आपका शहर (मौसम के लिए)", 13f, 0xFFB8B8D8.toInt()).apply { gravity = Gravity.START }, lp(18))
        val cityEt = field("जैसे: Indore", sp.getString("city", "") ?: "", false)
        addView(cityEt, lp(6))

        val searchSw = Switch(context).apply {
            text = "लाइव जानकारी (Google Search)"
            setTextColor(Color.WHITE)
            isChecked = sp.getBoolean("use_search", true)
        }
        addView(searchSw, lp(18))
        addView(label("लिमिट (429) की दिक्कत हो तो इसे बंद कर दें", 12f, 0xFF9A9AC0.toInt()), lp(4))


        val micVal = label("", 13f, 0xFFB8B8D8.toInt()).apply { gravity = Gravity.START }
        val micStart = (sp.getInt("mic_min", 1200) - 500).coerceIn(0, 2500)
        micVal.text = "माइक की संवेदनशीलता: ${micStart + 500}  (ज़्यादा = सिर्फ़ पास की आवाज़)"
        val micBar = SeekBar(context).apply {
            max = 2500
            progress = micStart
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    micVal.text = "माइक की संवेदनशीलता: ${p + 500}  (ज़्यादा = सिर्फ़ पास की आवाज़)"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        addView(micVal, lp(18))
        addView(micBar, lp(6))

        addView(button("💾  सेव करें", 0xFF7C4DFF.toInt()) {
            sp.edit()
                .putString("api_key", keyEt.text.toString().trim())
                .putString("city", cityEt.text.toString().trim())
                .putBoolean("use_search", searchSw.isChecked)
                .putInt("mic_min", micBar.progress + 500)
                .putString("model", modelEt.text.toString().trim()
                    .ifEmpty { AssistantService.DEFAULT_MODEL })
                .apply()
            Toast.makeText(context, "सेव हो गया ✅", Toast.LENGTH_SHORT).show()
        }, lp(24, MATCH, dp(56)))

        val testOut = TextView(context).apply {
            setTextColor(0xFFD0D0E8.toInt()); textSize = 12f; setTextIsSelectable(true)
        }
        addView(button("🧪  API टेस्ट करें (कौन सा मॉडल चलता है)", 0x22FFFFFF, 0x55FFFFFF) {
            runApiTest(keyEt.text.toString().trim(), modelEt, testOut)
        }, lp(12, MATCH, dp(52)))
        addView(testOut, lp(8))

        addView(button("🔑  API key कहाँ से लें", 0x22FFFFFF, 0x55FFFFFF) {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://aistudio.google.com/apikey")))
        }, lp(12, MATCH, dp(52)))

        addView(button("🧹  याददाश्त मिटाएँ", 0x22FFFFFF, 0x55FFFFFF) {
            getSharedPreferences("mem", MODE_PRIVATE).edit().remove("h").apply()
            Toast.makeText(context, "पुरानी बातचीत मिट गई", Toast.LENGTH_SHORT).show()
        }, lp(12, MATCH, dp(52)))

        addView(button("← वापस", 0x11FFFFFF, 0x33FFFFFF) { showSettings(false) },
            lp(12, MATCH, dp(52)))

        addView(label("बनाने वाले: धाकड़ 💪", 13f, 0xFF9A9AC0.toInt(), true), lp(36))
    }

    private fun showSettings(show: Boolean) {
        settingsScroll.visibility = if (show) View.VISIBLE else View.GONE
        homeScroll.visibility = if (show) View.GONE else View.VISIBLE
    }

    override fun onBackPressed() {
        if (settingsScroll.visibility == View.VISIBLE) showSettings(false) else super.onBackPressed()
    }

    override fun onResume() { super.onResume(); refresh() }

    /** key से कई मॉडल आज़माकर दिखाता है कि कौन सा चलता है, और पहला चलने वाला सेट कर देता है */
    private fun runApiTest(key: String, modelEt: EditText, out: TextView) {
        if (key.isEmpty()) {
            Toast.makeText(this, "पहले API key डालें", Toast.LENGTH_SHORT).show(); return
        }
        out.text = "जाँच चल रही है…"
        Thread {
            val models = listOf("gemini-3.5-flash-lite", "gemini-3.1-flash-lite",
                "gemini-2.5-flash-lite", "gemini-2.5-flash", "gemini-3.8-flash")
            val sb = StringBuilder()
            var firstOk: String? = null
            for (m in models) {
                try {
                    val conn = (java.net.URL(
                        "https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent")
                        .openConnection() as java.net.HttpURLConnection).apply {
                        requestMethod = "POST"; doOutput = true
                        connectTimeout = 15000; readTimeout = 30000
                        setRequestProperty("Content-Type", "application/json")
                        setRequestProperty("x-goog-api-key", key)
                    }
                    conn.outputStream.use {
                        it.write("""{"contents":[{"parts":[{"text":"hi"}]}]}""".toByteArray())
                    }
                    val code = conn.responseCode
                    val body = (if (code in 200..299) conn.inputStream else conn.errorStream)
                        ?.bufferedReader()?.readText() ?: ""
                    if (code in 200..299) {
                        sb.append("✅ $m: चल रहा है\n")
                        if (firstOk == null) firstOk = m
                    } else {
                        val msg = try {
                            org.json.JSONObject(body).getJSONObject("error").getString("message").take(160)
                        } catch (e: Exception) { "" }
                        sb.append("❌ $m: $code $msg\n")
                    }
                } catch (e: Exception) {
                    sb.append("❌ $m: ${e.javaClass.simpleName}\n")
                }
            }
            runOnUiThread {
                if (firstOk != null) {
                    sp.edit().putString("model", firstOk).apply()
                    modelEt.setText(firstOk)
                    sb.append("\nमॉडल अपने-आप '$firstOk' सेट हो गया। अब सुनना शुरू करें।")
                } else {
                    sb.append("\nकोई मॉडल नहीं चला। यह फ्री-टियर की रोक लगती है, AI Studio में बिलिंग चालू करें।")
                }
                out.text = sb.toString()
            }
        }.start()
    }

    private fun askAll() {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS, Manifest.permission.READ_CALENDAR)
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
        requestPermissions(p.toTypedArray(), 2)
    }

    // ---------- चालू / बंद ----------
    private fun refresh() {
        val on = sp.getBoolean("running", false)
        mainBtn.text = if (on) "⏹  बंद करें" else "🎤  सुनना शुरू करें"
        mainBtn.background = shape(if (on) 0xFFE53935.toInt() else 0xFF7C4DFF.toInt(), 32)
        status.text = if (on) "● असिस्टेंट सुन रहा है" else "○ असिस्टेंट बंद है"
        a11y.text = if (PhoneControlService.instance != null) "♿ एक्सेसिबिलिटी: चालू ✅"
        else "♿ एक्सेसिबिलिटी: बंद (फ़ोन कंट्रोल के लिए चालू करें)"
    }

    private fun toggle() {
        if (sp.getBoolean("running", false)) {
            stopService(Intent(this, AssistantService::class.java))
            sp.edit().putBoolean("running", false).apply(); refresh(); return
        }
        if (sp.getString("api_key", "").isNullOrBlank()) {
            Toast.makeText(this, "पहले सेटिंग में API key डालें", Toast.LENGTH_LONG).show()
            showSettings(true); return
        }
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            startAssistant()
        else requestPermissions(perms.toTypedArray(), 1)
    }

    private fun startAssistant() {
        startForegroundService(Intent(this, AssistantService::class.java))
        sp.edit().putBoolean("running", true).apply(); refresh()
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code != 1) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            startAssistant()
        else Toast.makeText(this, "माइक की परमिशन ज़रूरी है", Toast.LENGTH_LONG).show()
    }
}
